CLOUD HOP RUSH — PWA PREPARATION FILES

Included:
- index.html: your uploaded game, with PWA links/registration added
- manifest.webmanifest: app name, display mode, colors, and icons
- sw.js: basic offline caching
- icons/: app icons

IMPORTANT:
This ZIP is NOT an Android APK or Google Play AAB yet.
For PWABuilder's Google Play packaging, these files must first be hosted at a public HTTPS website.
After hosting, the site must be checked and the Android package generated, tested, and prepared for Play Console.
The game has not been fully browser/device tested by this packaging step.
